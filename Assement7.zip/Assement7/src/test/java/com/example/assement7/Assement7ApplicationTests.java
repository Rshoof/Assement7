package com.example.assement7;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assement7ApplicationTests {

    @Test
    void contextLoads() {
    }

}
