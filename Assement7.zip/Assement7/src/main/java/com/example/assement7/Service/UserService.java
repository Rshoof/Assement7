package com.example.assement7.Service;

import com.example.assement7.Model.User;
import com.example.assement7.Respository.UserRespository;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service @RequiredArgsConstructor@Data

public class UserService {
    private final UserRespository userRespository;

    public List<User> getUser() {
        return userRespository.findAll();
    }


    public void addUser(User user )
    {
        userRespository.save(user);
    }
    public Boolean updateUser(Integer id , User  user ){
        User olduser= userRespository.getById(id);
        if(olduser==null){
            return false;
        }
        olduser.setId(user.getId()) ;
        olduser.setUsername(olduser.getUsername()) ;
        olduser.setEmail(user.getEmail());
        olduser.setAge(user.getAge());
        olduser.setRole(user.getRole());
        olduser.setPassword(user.getPassword());
        userRespository.save(olduser);

        return true ;
    }

    public Boolean deleteUser(Integer id){
        User user = userRespository.getById(id);

        if(user == null){
            return false ;
        }
        userRespository.delete(user);
        return true;
    }


}
