package com.example.assement7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assement7Application {

    public static void main(String[] args) {
        SpringApplication.run(Assement7Application.class, args);
    }

}
