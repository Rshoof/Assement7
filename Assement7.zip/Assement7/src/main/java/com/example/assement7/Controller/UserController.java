package com.example.assement7.Controller;

import com.example.assement7.Dto.ApiResponse;
import com.example.assement7.Model.User;
import com.example.assement7.Service.UserService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController @RequestMapping("/api/v1")
public class UserController {
    private UserService  userService ;

    public UserController (UserService userService) {

        this.userService = userService;
    }

    @GetMapping("/get")
    public ResponseEntity getUser() {
        List<User> users = userService.getUser();
        return ResponseEntity.status(200).body(users);
    }

    @PostMapping("/add")
    public ResponseEntity addUser(@RequestBody @Valid User user , Errors error) {
        if (error.hasErrors()) {
            String message = error.getFieldError().getDefaultMessage();
            return ResponseEntity.status(400).body(new ApiResponse(message) );
        }
        userService.addUser(user);
        return ResponseEntity.status(200).body(new ApiResponse("User Added!"));
    }

    @PutMapping("/update/{index}")
    public ResponseEntity updateUser(@PathVariable Integer id, @RequestBody @Valid User user , Errors error) {
        if (error.hasErrors()) {
            String message = error.getFieldError().getDefaultMessage();
            return ResponseEntity.status(400).body(message);
        }
        boolean isUpdated = userService.updateUser(id , user) ;
        if (isUpdated) {
            return ResponseEntity.status(200).body(new ApiResponse("User update!"));
        }
        return ResponseEntity.status(400).body(new ApiResponse("wrong id!"));

    }
    @DeleteMapping ("/delete/{index}")
    public String deleteUser(@PathVariable Integer id) {
        userService.deleteUser(id);
        return "User_removed";
    }

}
